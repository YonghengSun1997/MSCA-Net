from .voc import VOCSegmentation
from .cityscapes import Cityscapes